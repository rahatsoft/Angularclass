import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../Services/service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  education:any
  allBlog:any
  constructor(
    private blogservice:ServiceService
  ) {
    this.allBlog=blogservice.getAllBlog().subscribe(
      (data:any)=>{ this.allBlog=data;  
        
      } )  }





  ngOnInit(): void {
  }

}
