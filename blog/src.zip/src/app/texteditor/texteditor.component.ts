import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-texteditor',
  templateUrl: './texteditor.component.html',
  styleUrls: ['./texteditor.component.css']
})
export class TexteditorComponent implements OnInit {
  description:any;
  constructor() { }

  ngOnInit(): void {
  }

}
