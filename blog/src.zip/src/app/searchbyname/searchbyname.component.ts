import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchbyname',
  templateUrl: './searchbyname.component.html',
  styleUrls: ['./searchbyname.component.css']
})
export class SearchbynameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
