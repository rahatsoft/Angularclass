export class Employee {
    emp_id:any;
    emp_name:any;
    emp_email:any;
    emp_password:any;

    constructor(emp_id:any,emp_name:any,emp_email:any,emp_password:any){
        this.emp_id=emp_id;
        this.emp_name=emp_name;
        this.emp_email=emp_email;
        this.emp_password=emp_password;
    }
}
