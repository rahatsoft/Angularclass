import { Comments } from './comments';

describe('Comments', () => {
  it('should create an instance', () => {
    expect(new Comments()).toBeTruthy();
  });
});
